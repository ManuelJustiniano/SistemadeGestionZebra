<?php
use yii\helpers\Url;
/* @var $this yii\web\View */

$configuracion = \app\models\Configuracion::find()->one();




?>

<div class="container">
    <div class="row">
        <div class="col-lg-12 cnstr">

            <h2 class="text-center">EN CONSTRUCCION</h2>
                <p class="text-center">Estamos trabajando en esta seccion</p>


        </div><!-- End .col-lg-9 -->






    </div><!-- End .row -->
</div><!-- End .container -->

<div class="mb-4"></div><!-- margin -->






